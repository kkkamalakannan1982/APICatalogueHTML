import React, {Component} from 'react';


class Header_part extends Component
{
    render()
    {
        return (
            <div className="header">
                <img className="logo" src={require('./images/pearlwatchlogo.png')} ></img>
                <div className="mainmenu">
                        <ul>
                        <li>API's</li><li>Documentation</li><li>About us</li><li>Community</li><li className="login-icon"><img src={require('./images/lock.png')} ></img>Login</li><li className="register-icon">Register</li>
                        </ul>
                </div>
            </div>
        )
    }
}
export default Header_part;
