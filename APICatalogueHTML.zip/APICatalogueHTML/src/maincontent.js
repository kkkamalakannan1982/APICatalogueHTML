import React, {Component} from 'react';

class Maincontent extends Component
{
    render()
    {
        return (
            <div>
                <div className="banner_section">
                    
                </div>
                <div class="exploreAPICatalogue">
                    <h1>Explore our API’s Catalogue</h1>
                    <p>Please browse and select your API below</p>
                </div>
                
               
                {/* <div className="article_section">
                    <div className="articles_box">
                        <span className="article_content">
                            <h1>For Developers</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam a sodales urna. Quisque felis nulla, gravida sit amet malesuada at, scelerisque et mi. Donec tincidunt sapien id finibus condimentum</p>
                        </span>
                        <img src={require('./images/for_developers.png')} ></img>
                    </div>
                    <div className="articles_box">
                        <img src={require('./images/for_business.png')} ></img>
                        <span className="article_content">
                            <h1>For Business</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam a sodales urna. Quisque felis nulla, gravida sit amet malesuada at, scelerisque et mi. Donec tincidunt sapien id finibus condimentum</p>
                        </span>
                    </div>
                    
                </div> */}
            </div>
        )
    }
}
export default Maincontent;