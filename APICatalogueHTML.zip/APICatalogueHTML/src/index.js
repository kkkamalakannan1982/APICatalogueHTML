import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Header_part from './header';
import Maincontent from './maincontent';
import Cardsection from './cardssection';
// import App from './App';
// import * as serviceWorker from './serviceWorker';


function Header()
{
    return(
        <Header_part/>
    )
}
function Main()
{
    return(
        <Maincontent/>
    )
}
function Cardssection()
{
    return(
        <Cardsection/>
    )
}
function Layout()
{
    return(
        <div>
            <Header/> <Main/> <Cardssection/>
        </div>
    )
}

ReactDOM.render(<Layout/>, document.getElementById("root"));
// function Main()
// {
//     return(
//         <div>
//             <div className="banner_section">
//                 <h1>Building tomorrow’s future With our technology</h1>
//                 <p>Here at FAB we love technology and collaborating with tech people</p>
//                 <a href="../themes/layout/apicatalog"><button className="learn_more">Learn More</button></a>
//             </div>
//             <div className="cards_section">
//                 <div className="cards">
//                     <h1><img src={require('./images/API.png')} ></img> API’s</h1>
//                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
//                     <button className="card_btn">Browse Catalogue <img src={require('./images/cards_go.png')} ></img></button>
//                 </div>
//                 <div className="cards">
//                     <h1><img src={require('./images/getting_started.png')} ></img> Getting Started</h1>
//                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
//                     <button className="card_btn">Register Now <img src={require('./images/cards_go.png')} ></img></button>
//                 </div>
//                 <div className="cards">
//                     <h1><img src={require('./images/test_API.png')} ></img> Test your API</h1>
//                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
//                     <button className="card_btn">Learn More <img src={require('./images/cards_go.png')} ></img></button>
//                 </div>
//                 <div className="cards">
//                     <h1><img src={require('./images/use_case.png')} ></img> Use cases</h1>
//                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
//                     <button className="card_btn">Learn More <img src={require('./images/cards_go.png')} ></img></button>
//                 </div>
//             </div>
//             <div className="article_section">
//                 <div className="articles_box">
//                     <span className="article_content">
//                         <h1>For Developers</h1>
//                         <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam a sodales urna. Quisque felis nulla, gravida sit amet malesuada at, scelerisque et mi. Donec tincidunt sapien id finibus condimentum</p>
//                     </span>
//                     <img src={require('./images/for_developers.png')} ></img>
//                 </div>
//                 <div className="articles_box">
//                     <img src={require('./images/for_business.png')} ></img>
//                     <span className="article_content">
//                         <h1>For Business</h1>
//                         <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam a sodales urna. Quisque felis nulla, gravida sit amet malesuada at, scelerisque et mi. Donec tincidunt sapien id finibus condimentum</p>
//                     </span>
//                 </div>
                
//             </div>
//         </div>
//     )
// }



// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
//serviceWorker.unregister();
