import React, {Component} from 'react';

class Cardsection extends Component
{
    render()
    {
        return (
                 <div className="cards_section">
                    <div className="all_Catalogues"><select><option>All Catalogues</option></select></div>
                    <div className="cards">
                        <img src={require('./images/API.png')} ></img>
                        <h1>API’s</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
                        <button className="card_btn">Browse Catalogue <img src={require('./images/cards_go.png')} ></img></button>
                    </div>
                    <div className="cards">
                        <img src={require('./images/getting_started.png')} ></img>
                        <h1>Getting Started</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
                        <button className="card_btn">Register Now <img src={require('./images/cards_go.png')} ></img></button>
                    </div>
                    <div className="cards">
                        <img src={require('./images/test_API.png')} ></img>
                        <h1>Test your API</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
                        <button className="card_btn">Learn More <img src={require('./images/cards_go.png')} ></img></button>
                    </div>
                    <div className="cards">
                        <img src={require('./images/use_case.png')} ></img>
                        <h1> Use cases</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
                        <button className="card_btn">Learn More <img src={require('./images/cards_go.png')} ></img></button>
                    </div>
                    <div className="cards">
                        <img src={require('./images/use_case.png')} ></img>
                        <h1> Use cases</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
                        <button className="card_btn">Learn More <img src={require('./images/cards_go.png')} ></img></button>
                    </div>
                    <div className="cards">
                        <img src={require('./images/use_case.png')} ></img>
                        <h1> Use cases</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
                        <button className="card_btn">Learn More <img src={require('./images/cards_go.png')} ></img></button>
                    </div>
                    <div className="cards">
                        <img src={require('./images/use_case.png')} ></img>
                        <h1> Use cases</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec magna velit.</p>
                        <button className="card_btn">Learn More <img src={require('./images/cards_go.png')} ></img></button>
                    </div>
                </div>
            )
    }
}
export default Cardsection;